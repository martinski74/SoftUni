﻿
namespace Animal
{
    public interface IProduseSound
    {
        string ProduceSound();
    }
}
