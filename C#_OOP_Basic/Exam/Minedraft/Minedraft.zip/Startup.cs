﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Minedraft
{
    public class Startup
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
