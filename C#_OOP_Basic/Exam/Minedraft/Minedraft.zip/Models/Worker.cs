﻿
public abstract class Worker
{
    private string id;

    protected Worker(string id)
    {
        this.id = id;
    }
}

